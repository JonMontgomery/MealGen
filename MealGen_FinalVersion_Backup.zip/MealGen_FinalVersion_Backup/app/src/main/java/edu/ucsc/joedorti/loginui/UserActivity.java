package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserActivity extends MainActivity {
    private TextView tvUser;

    public static final String EXTRA_NUMBER1 = "com.example.connormonson.assignment2.EXTRA_NUMBER1";
    public static final String EXTRA_NUMBER2 = "com.example.connormonson.assignment2.EXTRA_NUMBER2";
    public static final String EXTRA_NUMBER3 = "com.example.connormonson.assignment2.EXTRA_NUMBER3";

    private Button searchButton;
    EditText et1;
    EditText et2;
    EditText et3;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        tvUser = findViewById(R.id.tvUser);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            tvUser.setText(bundle.getString("user"));
        }

        et1 = (EditText) findViewById(R.id.edittext1);
        et2 = (EditText) findViewById(R.id.edittext2);
        et3 = (EditText) findViewById(R.id.edittext3);
        db = new DatabaseHelper(this);

        searchButton = (Button) findViewById(R.id.buttonDone);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str1 = et1.getText().toString();
                String str2 = et2.getText().toString();
                String str3 = et3.getText().toString();

                openView(str1, str2, str3);

            }
        });
    }
    /*
     * put all the activities here
     * */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.get_meal) {
            // Handle the meal action
            Intent intent = new Intent(UserActivity.this, UserActivity.class);
            startActivity(intent);

        } else if (id == R.id.view_meals) {
            Intent intent = new Intent(UserActivity.this, ViewAll.class);
            startActivity(intent);

        } else if (id == R.id.ingredients) {
            Intent intent = new Intent(UserActivity.this, IngredientList.class);
            startActivity(intent);
        } else if (id == R.id.calander) {
            Intent intent = new Intent(UserActivity.this, CalendarActivity.class);
            startActivity(intent);
        } else if (id == R.id.favorites) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }else if (id == R.id.Logout) { finish();
            System.exit(0);

        }else if (id == R.id.Exit) { finish();
            System.exit(0);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void openView(String str1, String str2, String str3){
        Intent intent = new Intent(this, view.class);
        intent.putExtra("num1", str1);
        intent.putExtra("num2", str2);
        intent.putExtra("num3", str3);

        //intent.putExtra(EXTRA_NUMBER1, str1);
        //intent.putExtra(EXTRA_NUMBER2, str2);
        //intent.putExtra(EXTRA_NUMBER3, str3);

        startActivity(intent);
    }

    public void insertData(){
        /*
        //pasta
        db.addData("Creamy Cajun Chicken Pasta","https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "4 ounces linguine, 2 boneless chicken breast, 2 teaspoons of Cajun spices, 2 tablesponns of butter, 1 green bell pepper, 1/2 red bell pepper, 1 green onion, lemon pepper, salt", "pasta", "https://www.allrecipes.com/recipe/12009/creamy-cajun-chicken-pasta/?internalSource=hub%20recipe&referringContentType=Search&clickId=cardslot%202");

        db.addData("Pasta Fazool (Pasta e Fagioli)", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "12 ounce of italian sausage, 1 tablespoon olive oil, 1 stalk celery, 1/2 yellow onion chopped, 3/4 cup dry elbow macaroni, 1 (15 ounce) can cannellini (white kidney) beans, drained, more", "pasta", "https://www.allrecipes.com/recipe/255823/pasta-fazool-pasta-e-fagioli/?internalSource=hub%20recipe&referringContentType=Search&clickId=cardslot%203");

        db.addData("Greek Pasta Salad I", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, 2 1/2 cups dry elbow macaroni, more", "pasta", "https://www.allrecipes.com/recipe/11689/greek-pasta-salad-i/?internalSource=hub%20recipe&referringContentType=Search&clickId=cardslot%204");

        db.addData("One Pan Orecchiette Pasta", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "8 ounces of spicey italian sausage, 1 1/4 cups orecchiette pasta, 1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, more", "pasta", "https://www.allrecipes.com/recipe/239047/one-pan-orecchiette-pasta/?internalSource=hub%20recipe&referringContentType=Search&clickId=cardslot%205");

        db.addData("Cajun Chicken Pasta", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "4 ounces linguine pasta, 1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, 2 table spoons of butter, 1 red pepper, 1 green pepper, garlic powder, lemon pepper, more", "pasta", "https://www.allrecipes.com/recipe/8778/cajun-chicken-pasta/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Champagne Shrimp and Pasta", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", " 12 ounces of shrimp, 4 ounces linguine pasta, 1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, 2 table spoons of butter, 1 red pepper, 1 green pepper, garlic powder, lemon pepper, more", "pasta","https://www.allrecipes.com/recipe/42586/champagne-shrimp-and-pasta/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Sausage Pasta", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "12 ounces of spicey italian sausage, 1 1/4 cups orecchiette pasta, 1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, more", "pasta", "https://www.allrecipes.com/recipe/19291/sausage-pasta/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Chicken Club Pasta Salad", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "12 ounces of spicey italian sausage, 1 1/4 cups orecchiette pasta, 1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, more", "pasta", "https://www.allrecipes.com/recipe/236198/chicken-club-pasta-salad/?internalSource=hub%20recipe&referringContentType=Search&clickId=cardslot%2011");

        db.addData("Chicken Club Pasta Salad","https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "4 ounces linguine, 2 boneless chicken breast, 2 teaspoons of Cajun spices, 2 tablesponns of butter, 1 green bell pepper, 1/2 red bell pepper, 1 green onion, lemon pepper, salt", "pasta", "https://www.allrecipes.com/recipe/236198/chicken-club-pasta-salad/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Shrimp Scampi with Pasta", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "12 ounces of shrimp, 1/2 cup olive oil, 1/2 cup red wine, 3 cups fresh sliced mushrooms, more", "pasta", "https://www.allrecipes.com/recipe/229960/shrimp-scampi-with-pasta/?internalSource=hub%20recipe&referringContentType=Search");


        //shrimp
        db.addData("Lemon-Garlic Shrimp and Grits", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1 cup stone ground grits, 1 pound medium shrimp pealed and deveined, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/220894/lemon-garlic-shrimp-and-grits/?internalSource=rotd&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Shrimp Verde", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1 pound medium shrimp pealed and deveined, verde sauce, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/25867/shrimp-verde/?internalSource=staff%20pick&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Honey Walnut Shrimp", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1 pound medium shrimp pealed and deveined, 4 egg-whites, mochiko, 2 tablespoons honey, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/93234/honey-walnut-shrimp/?internalSource=staff%20pick&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Szechwan Shrimp", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "Szechwan sauce, 1 pound medium shrimp pealed and deveined, 4 egg-whites, mochiko, 2 tablespoons honey, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/86230/szechwan-shrimp/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Shrimp Scampi Bake", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1/2 pound medium shrimp pealed and deveined, 4 egg-whites, mochiko, 2 tablespoons honey, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, more", "shrimp", "https://www.allrecipes.com/recipe/25874/shrimp-scampi-bake/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Peppered Shrimp Alfredo", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "pepper, alfredo sauce, 1 pound medium shrimp pealed and deveined, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/133128/peppered-shrimp-alfredo/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Grilled Marinated Shrimp", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1 pound large shrimp pealed and deveined, 2 tablespoons honey, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/19484/grilled-marinated-shrimp/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Simple Garlic Shrimp", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, 1/2 pound small shrimp pealed and deveined, 2 tablespoons honey, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, more", "shrimp", "https://www.allrecipes.com/recipe/220597/simple-garlic-shrimp/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Spicy Grilled Shrimp", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1 pound large shrimp pealed and deveined, 2 tablespoons honey, 1/2 lemon, 2 tablespoons water, spices, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/12775/spicy-grilled-shrimp/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");

        db.addData("Grilled Shrimp Scampi", "https://images.media-allrecipes.com/userphotos/300x300/1001970.jpg", "1 pound medium shrimp, 2 tablespoons honey, scampy, 1/2 lemon, 2 tablespoons water, 1 pinch pepper, 2 large cloves garlic, 1/2 teaspoon fresh ground black pepper, 2 tablespoons butter, more", "shrimp", "https://www.allrecipes.com/recipe/12771/grilled-shrimp-scampi/?internalSource=hub%20recipe&referringId=430&referringContentType=Recipe%20Hub");


        // beef
        db.addData("Easy Meatloaf", "https://images.media-allrecipes.com/userphotos/720x405/682282.jpg", "1 1/2 pounds ground beef, 1 egg, 1 onion, 1 cup milk, 1 cup dried bread crumbs, 2 tablespoons brown sugar, 1/3 cup ketchup", "beef", "https://www.allrecipes.com/recipe/16354/easy-meatloaf/?internalSource=streams&referringId=998&referringContentType=Recipe%20Hub&clickId=st_trending_s");

        db.addData("Classic Spicy Meatloaf", "https://images.media-allrecipes.com/userphotos/720x405/682282.jpg", "1 cup onion, 2 teaspoons salt, 1 1/2 ground beef, 3/4 pound ground spicy pork sausage, 1 cup bread crumbs, 1 carrot, 1 rib celery", "beef", "https://www.allrecipes.com/recipe/235250/classic-spicy-meatloaf/?internalSource=streams&referringId=256&referringContentType=Recipe%20Hub&clickId=st_trending_s");

        db.addData("Tennesse Meatloaf", "https://images.media-allrecipes.com/userphotos/720x405/682282.jpg", "1 onion, 1/2 green bell pepper, 2 large eggs, 1/2 cup milk, 1 pound ground beef, 1/2 pound ground pork, 1/2 pound ground veal", "beef", "https://www.allrecipes.com/recipe/232247/tennessee-meatloaf/?internalSource=streams&referringId=256&referringContentType=Recipe%20Hub&clickId=st_trending_b");

        db.addData("Glazed Meatloaf", "https://images.media-allrecipes.com/userphotos/720x405/682282.jpg", "1 onion, 1/2 green bell pepper, 2 large eggs, 1/2 cup milk, 1 pound ground beef, 1/2 pound ground pork, 1/2 pound ground veal", "beef", "https://www.allrecipes.com/recipe/20673/glazed-meatloaf-ii/?internalSource=staff%20pick&referringId=256&referringContentType=Recipe%20Hub");

        db.addData("Mini Meatloves", "https://images.media-allrecipes.com/userphotos/720x405/682282.jpg", "1 tablespoon vegetable oil, 1/2 green bell pepper, 2 large eggs, 1/2 cup milk, 1 pound ground beef", "beef", "https://www.allrecipes.com/recipe/15715/mini-meatloaves/?internalSource=staff%20pick&referringId=256&referringContentType=Recipe%20Hub");


        // tuna
        db.addData("Grilled Tuna with Fresh Horseradish", "https://images.media-allrecipes.com/userphotos/720x405/5277380.jpg", "2 fresh tuna steaks, 1 teaspoon vegetable oil, 2 tablespoons soy sauce, 4 cherry tomatoes, 1 tablespoon minced green onion", "tuna", "https://www.allrecipes.com/recipe/222190/grilled-tuna-with-fresh-horseradish/?internalSource=streams&referringId=415&referringContentType=Recipe%20Hub&clickId=st_trending_s");

        db.addData("Easy Tuna Patties", "https://images.media-allrecipes.com/userphotos/720x405/1031128.jpg", "2 eggs, 2 teaspoons lemon juice, 3 tablespoons, grated Parmesean cheese, 3 cans tuna(drained), 1 pinch ground black pepper, 3 tablespoons vegetable oil", "tuna", "https://www.allrecipes.com/recipe/230857/easy-tuna-patties/?internalSource=streams&referringId=415&referringContentType=Recipe%20Hub&clickId=st_trending_s");

        db.addData("Easy Tuna Casserole", "https://images.media-allrecipes.com/userphotos/720x405/4560684.jpg", "3 cups cooked macaroni, 1 can tuna, 1 can chicken soup, 1 cup shredded cheddar cheese", "tuna", "https://www.allrecipes.com/recipe/18871/easy-tuna-casserole/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Sesame Seared Tuna", "https://images.media-allrecipes.com/userphotos/720x405/4560684.jpg", "1/4 cup soy sauce, 1 tablespoon honey, 4 tuna steaks, wasabi paste, 1 tablespoon olive oil", "tuna", "https://www.allrecipes.com/recipe/230857/easy-tuna-patties/?internalSource=streams&referringId=415&referringContentType=Recipe%20Hub&clickId=st_trending_s");

        db.addData("Avocado and Tuna Tapas", "https://images.media-allrecipes.com/userphotos/720x405/4560684.jpg", "1 can solid white tuna, 1 tablespoon mayonaise, 3 green onions, 1/2 red bell pepper, 2 ripe avocados, black pepper", "tuna", "https://www.allrecipes.com/recipe/139620/avocado-and-tuna-tapas/?internalSource=streams&referringId=415&referringContentType=Recipe%20Hub&clickId=st_trending_s");


        //potatoes
        db.addData("Bacon and Blue Cheese Potato Pancakes", "https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg", "4 slices bacon, 2 pounds cubed potatoes, 1/3 cup crumbled blue cheese, 1/4 cup 1% low-fat milk, 1 egg, 3 green onions thinly sliced, 3/4 teaspoon salt, 1/4 teaspoon freshly ground pepper, 1/2 cup bread crumbs, 1 1/2 tablespoons olive oil, 1 tablespoon butter", "potatoes", "https://www.allrecipes.com/recipe/255637/bacon-and-blue-cheese-potato-pancakes/?internalSource=staff%20pick&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Creamy Au Gratin Potatoes", "https://images.media-allrecipes.com/userphotos/720x405/2142598.jpg", "4 russet potatoes sliced into 1/4 inch slices, 1 onion sliced into rings, salt and pepper to taste, 3 tablespoons butter, 1/2 teaspoon salt, 2 cups milk, 1 1/2 cups shredded Cheddar cheese", "potatoes", "https://www.allrecipes.com/recipe/15925/creamy-au-gratin-potatoes/?internalSource=rotd&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Perfect Potato Soup", "https://images.media-allrecipes.com/userphotos/600x600/5816671.jpg", "6 russet potatoes peeled and cut into 1/2 inch cubes, 5 slice bacon, 3 tablespoon butter, 2 stalk celery, 1/2 large onion diced, 20 baby carrots, more...", "potatoes", "https://www.allrecipes.com/recipe/255487/perfect-potato-soup/?internalSource=staff%20pick&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Fall-Infused Mashed Potatoes", "https://www.tasteofhome.com/wp-content/uploads/2017/10/exps105419_LR153742D08_04_6b--696x696.jpg", "1 acorn squash, water as needed, 5 white potatoes diced, 2 tablespoons butter, 1 tablespoon Dijon mustard, 1/2 teaspoon dried dill weed, salt and ground black pepper to taste, 1/2 cup milk", "potatoes", "https://www.allrecipes.com/recipe/245559/fall-infused-mashed-potatoes/?internalSource=staff%20pick&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Cheesy Ham and Hash Brown Casserole", "https://images.media-allrecipes.com/userphotos/600x600/5816671.jpg", "1 package frozen frozen hash brown potatoes, 8 ounces diced cooked ham, 2 cans condensed cream of potato soup, 1 container sour cream, 2 cups shredded sharp Cheddar cheese, 1 1/2 cups grated Parmesan cheese", "potatoes", "https://www.allrecipes.com/recipe/20096/cheesy-ham-and-hash-brown-casserole/?internalSource=hub%20recipe&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Red Skinned Potato Salad", "https://images.media-allrecipes.com/userphotos/600x600/5816671.jpg", "2 pounds clean red potatoes, 6 eggs, 1 pound bacon, 1 onion, 1 stalk celery, 2 cups mayonnaise, salt and pepper", "potatoes", "https://www.allrecipes.com/recipe/25155/red-skinned-potato-salad/?internalSource=hub%20recipe&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Baked French Fries", "https://images.media-allrecipes.com/userphotos/560x315/1908299.jpg", "1 large baking potato, 1 tablespoon olive oil, 1/2 tablespoon paprika, 1/2 teaspoon garlic powder, 1/2 teaspoon chili powder, 1/2 teaspoon garlic powder", "potatoes", "https://www.allrecipes.com/recipe/20849/baked-french-fries-i/?internalSource=hub%20recipe&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Oven Roasted Potatoes", "https://images.media-allrecipes.com/userphotos/560x315/4559332.jpg", "2 pounds clean red potatoes, 6 eggs, 1 pound bacon, 1 onion, 1 stalk celery, 2 cups mayonnaise, salt and pepper", "potatoes", "https://www.allrecipes.com/recipe/20963/oven-roasted-potatoes/?internalSource=hub%20recipe&referringId=1540&referringContentType=Recipe%20Hub");

        db.addData("Authentic German Potato Salad", "https://images.media-allrecipes.com/userphotos/560x315/1908299.jpg", "3 cups diced peeled potatoes, 4 slices bacon, 1 small diced onion, 1/4 cup white vinegar, 2 tablespoons water, more...", "potatoes", "https://www.allrecipes.com/recipe/83097/authentic-german-potato-salad/?internalSource=recipe%20hub&referringId=1540&referringContentType=Recipe%20Hub&clickId=cardslot%2021");

        db.addData("Golden Potato Soup", "https://images.media-allrecipes.com/userphotos/560x315/1908299.jpg", "3 cups peeled and cubed potatoes, 1/2 cup chopped celery, 1/2 cup chopped onion, 1 cube chicken boullion, 1 cup water, more...", "potatoes", "https://www.allrecipes.com/recipe/13316/golden-potato-soup/?internalSource=recipe%20hub&referringId=1540&referringContentType=Recipe%20Hub&clickId=cardslot%2026");

        //spinach
        db.addData("Spinach Quiche", "https://images.media-allrecipes.com/userphotos/250x250/188603.jpg", "1/2 cup butter, 3 cloves chopped garlic, 1 small onion chopped, 1 package frozen chopped spinach thawed and drained, more...", "spinach", "https://www.allrecipes.com/recipe/16664/spinach-quiche/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Strawberry Spinach Salad", "https://images.media-allrecipes.com/userphotos/250x250/188603.jpg", "2 tablespoons sesame seed, 1 tablespoon poppy seed, 1/2 cup white sugar, 1/2 cup olive oil, 1/4 cup distilled white vinegar, more...", "spinach", "https://www.allrecipes.com/recipe/14276/strawberry-spinach-salad-i/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Best Spinach Dip Ever", "https://images.media-allrecipes.com/userphotos/560x315/4559332.jpg", "1 cup mayonnaise, 1 container sour cream, 1 package dry leek soup mix, 1 can water chestnuts, 1/2 package frozen chopped spinach, 1 loaf round sourdough", "spinach", "https://www.allrecipes.com/recipe/22617/best-spinach-dip-ever/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Spinach Tomato Tortellini", "https://images.media-allrecipes.com/userphotos/560x315/1908299.jpg", "1 package cheese tortellini, 1 can diced tomatoes with garlic and onion, 1 cup fresh chopped spinach, 1/2 teaspoon salt, 1/4 teaspoon pepper, more...", "spinach", "https://www.allrecipes.com/recipe/76129/spinach-tomato-tortellini/?internalSource=hub%20recipe&referringContentType=Search");

        db.addData("Cheesey Creamed Spinach", "https://therecipecritic.com/wp-content/uploads/2017/12/brown_sugar_garlic_salmon-1-of-1.jpg", "3 bags clean chopped spinach, 1 1/4 cups heavy cream, 1/4 cup butter, 2 tablespoons minced garlic, 3 tablespoons minced white onion, 6 slices shredded provolone cheese, 1/2 cup freshly grated Parmesan cheese, salt and pepper to taste", "spinach", "https://www.allrecipes.com/recipe/67132/cheesy-creamed-spinach/?internalSource=hub%20recipe&referringContentType=Search");
                */

                /*
                db.addData("Chicken Parmeson","https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg","4 skinless boneless chicken breast halves, 2 eggs , 1/2 cup of tomato sause, 1/2 cup of grated parmeson cheese, 2 tablespoons flour, salt, pepper, 1/4 cup chopped fresh basil, 1 tablespoon olive oil", "chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                db.addData("Crispy Fried Chicken","https://images.media-allrecipes.com/userphotos/720x405/2142598.jpg","1 cup buttermilk , 2 cups flour, 2 cups paprika, salt, pepper,1 cup vegetable oil","chicken","https://www.allrecipes.com/recipe/8805/crispy-fried-chicken/");

                db.addData("Chicken Katsu","https://images.media-allrecipes.com/userphotos/600x600/5816671.jpg","1 egg , 2 tablespoons flour, 1 cup panko bread crumbs, salt, pepper, 1 cup olive oil","chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                db.addData("Chicken Sandwich","https://www.tasteofhome.com/wp-content/uploads/2017/10/exps105419_LR153742D08_04_6b--696x696.jpg","1/4 cup reduced-fat mayonnaise, 1 tablespoon Dijon mustard, 1 tablespoon honey, 4 boneless skinless chicken breast halves (4 ounces each),1/2 teaspoon Montreal steak seasoning, 4 slices Swiss cheese, 4 whole wheat hamburger buns split,2 bacon strips cooked and crumbled, Lettuce leaves and tomato slices","chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                // lettuce
                db.addData("Artichoke Salad","https://food.fnr.sndimg.com/content/dam/images/food/fullset/2008/12/22/0/BX0109_Roasted-Artichoke-Salad.jpg.rend.hgtvcom.826.620.suffix/1434689343188.jpeg","4 boxes (9 ounces each) frozen artichoke hearts defrosted, olive oil, Kosher salt and freshly ground black pepper, 1 shallot minced, 3 tablespoons freshly squeezed lemon juice, 1 teaspoon Dijon mustard, 5 tablespoons white wine vinegar or champagne vinegar, divided, 1/2 cup chopped fresh basil leaves, 6 tablespoons capers drained, 2 roasted red peppers, sliced thin, 1/2 cup minced red onion, 1/2 cup chopped fresh parsley leaves, 2 pinches hot red pepper flakes","lettuce","https://www.foodnetwork.com/recipes/ina-garten/roasted-artichoke-salad-recipe-1944268");

                db.addData("Classic Caeser Salad","https://www.bonappetit.com/recipe/classic-caesar-salad","3 romaine hearts, parmeson, croutons, 2 tablespoon olive oil , ranch","lettuce", "https://www.bonappetit.com/recipe/classic-caesar-salad");

                db.addData("Holiday Lettuce Salad","https://www.tasteofhome.com/wp-content/uploads/2017/10/Holiday-Lettuce-Salad_exps41195_CW132792B07_09_6bC_RMS-696x696.jpg","10 cups torn romaine, 2 medium red apples, cubed, 2 medium pears, cubed, 1 cup shredded Swiss cheese, 1/2 cup dried cranberries, 6 tablespoons lemon juice, 3 tablespoons canola oil, 3 tablespoons light corn syrup,1-1/2 teaspoons grated onion, 1-1/2 teaspoons, Dijon mustard, 1/2 teaspoon salt 1/2 cup chopped lightly salted cashews","lettuce", "https://www.tasteofhome.com/recipes/holiday-lettuce-salad");

                //pork chop
                db.addData("Oven-Fried Pork Chops", "https://images.media-allrecipes.com/userphotos/560x315/1908299.jpg", "½ teapsoon garlic powder, 1 pinch pound ginger, 1 cup bread crumbs, 4 pork chops, 1 medium egg, 3 tablespoons of soy sauce", "pork chops", "https://www.allrecipes.com/recipe/239948/easy-oven-fried-pork-chops");

                db.addData("Summer Grilled Pork Chops", "https://images.media-allrecipes.com/userphotos/560x315/4559332.jpg", "1 ½ cups lemon juice, 1 ½ honey, 1 clove garlic minced, ¼ teaspoon dried basil, 4 center-cut pork chops, ½-inch thick, salt and pepper", "pork chops", "https://www.allrecipes.com/recipe/218079/summer-grilled-pork-chops");

                db.addData("Tangy Sliced Pork Sandwiches", "https://images.media-allrecipes.com/userphotos/250x250/188603.jpg", "¼ cup butter, 2 tablespoons of lemon juice, 2 tablespoons white sugar, ¼ teaspoon paprika, ⅛ teaspoon salt, ½ pound boneless pork cooked and cubed, hamburger buns", "pork chops", "https://www.allrecipes.com/recipe/14706/tangy-sliced-pork-sandwiches");

                // salmon
                db.addData("Oven Baked Salmon"," https://food.fnr.sndimg.com/content/dam/images/food/fullset/2011/7/26/1/CN1B01_oven-baked-salmon_s4x3.jpg.rend.hgtvcom.826.620.suffix/1382545141944.jpeg","12 ounce salmon fillet, cut into 4 pieces, Coarse-grained salt, Freshly ground black pepper, Toasted Almond Parsley Salsa, for serving, Baked squash, for serving, optional","salmon", "https://www.foodnetwork.com/recipes/oven-baked-salmon-recipe-1911951");

                db.addData("Garlic Brown Sugar Glazed Salmon", "https://therecipecritic.com/wp-content/uploads/2017/12/brown_sugar_garlic_salmon-1-of-1.jpg", "2 pounds salmon, Atlantic salmon, 2 Tablespoons olive oil, ¼ cup brown sugar, ¼ cup soy sauce, 3 garlic cloves, minced, juice of one lemon,1 teaspoon salt, ½ teaspoon pepper, garnish with sliced lemons and chopped parsley if desired", "salmon", "https://therecipecritic.com/garlic-brown-sugar-glazed-salmon/");

                db.addData("Baked Salmon in Foil", "https://www.wellplated.com/wp-content/uploads/2018/06/Baked-Salmon-in-Foil-at-400-600x847.jpg", "2 pound side of salmon, 5 springs fresh rosemary, 2 small lemons , 2 tablespoons extra virgin olive oil, 1 teaspoon kosher salt , 1/4 teaspoon ground black pepper, 4 cloves garlic — peeled and roughly chopped, additional chopped fresh herbs", "salmon", "https://www.wellplated.com/baked-salmon-in-foil/");

                toastMessage("Added lettuce, pork chop, salmon to Database");
                */
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}