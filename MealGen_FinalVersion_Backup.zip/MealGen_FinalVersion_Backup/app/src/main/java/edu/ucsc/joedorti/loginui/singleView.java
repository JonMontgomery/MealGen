package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class singleView extends AppCompatActivity {

    DatabaseHelper myDatabaseHelper;
    TextView tv;
    TextView tv2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_view);

        Intent intent = getIntent();
        String str1 = intent.getStringExtra(view.SINGLE);
        String str2 = intent.getStringExtra(view.LINK);

        myDatabaseHelper = new DatabaseHelper(this);
        tv = (TextView) findViewById(R.id.singleText);
        tv2 = (TextView) findViewById(R.id.textLink);

        tv.setText(str1);
        tv2.setText(str2);



    }
}
