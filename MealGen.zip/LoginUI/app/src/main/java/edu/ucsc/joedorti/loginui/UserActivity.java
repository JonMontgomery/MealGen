package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserActivity extends AppCompatActivity {
    private TextView tvUser;

    public static final String EXTRA_NUMBER1 = "com.example.connormonson.assignment2.EXTRA_NUMBER1";
    public static final String EXTRA_NUMBER2 = "com.example.connormonson.assignment2.EXTRA_NUMBER2";
    public static final String EXTRA_NUMBER3 = "com.example.connormonson.assignment2.EXTRA_NUMBER3";

    private Button searchButton;
    EditText et1;
    EditText et2;
    EditText et3;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        tvUser = findViewById(R.id.tvUser);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            tvUser.setText(bundle.getString("user"));
        }

        et1 = (EditText) findViewById(R.id.edittext1);
        et2 = (EditText) findViewById(R.id.edittext2);
        et3 = (EditText) findViewById(R.id.edittext3);
        db = new DatabaseHelper(this);

        searchButton = (Button) findViewById(R.id.buttonDone);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str1 = et1.getText().toString();
                String str2 = et2.getText().toString();
                String str3 = et3.getText().toString();


                /*
                db.addData("Chicken Parmeson","https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg","4 skinless boneless chicken breast halves, 2 eggs , 1/2 cup of tomato sause, 1/2 cup of grated parmeson cheese, 2 tablespoons flour, salt, pepper, 1/4 cup chopped fresh basil, 1 tablespoon olive oil", "chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                db.addData("Crispy Fried Chicken","https://images.media-allrecipes.com/userphotos/720x405/2142598.jpg","1 cup buttermilk , 2 cups flour, 2 cups paprika, salt, pepper,1 cup vegetable oil","chicken","https://www.allrecipes.com/recipe/8805/crispy-fried-chicken/");

                db.addData("Chicken Katsu","https://images.media-allrecipes.com/userphotos/600x600/5816671.jpg","1 egg , 2 tablespoons flour, 1 cup panko bread crumbs, salt, pepper, 1 cup olive oil","chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                db.addData("Chicken Sandwich","https://www.tasteofhome.com/wp-content/uploads/2017/10/exps105419_LR153742D08_04_6b--696x696.jpg","1/4 cup reduced-fat mayonnaise, 1 tablespoon Dijon mustard, 1 tablespoon honey, 4 boneless skinless chicken breast halves (4 ounces each),1/2 teaspoon Montreal steak seasoning, 4 slices Swiss cheese, 4 whole wheat hamburger buns split,2 bacon strips cooked and crumbled, Lettuce leaves and tomato slices","chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                // lettuce
                db.addData("Artichoke Salad","https://food.fnr.sndimg.com/content/dam/images/food/fullset/2008/12/22/0/BX0109_Roasted-Artichoke-Salad.jpg.rend.hgtvcom.826.620.suffix/1434689343188.jpeg","4 boxes (9 ounces each) frozen artichoke hearts defrosted, olive oil, Kosher salt and freshly ground black pepper, 1 shallot minced, 3 tablespoons freshly squeezed lemon juice, 1 teaspoon Dijon mustard, 5 tablespoons white wine vinegar or champagne vinegar, divided, 1/2 cup chopped fresh basil leaves, 6 tablespoons capers drained, 2 roasted red peppers, sliced thin, 1/2 cup minced red onion, 1/2 cup chopped fresh parsley leaves, 2 pinches hot red pepper flakes","lettuce","https://www.foodnetwork.com/recipes/ina-garten/roasted-artichoke-salad-recipe-1944268");

                db.addData("Classic Caeser Salad","https://www.bonappetit.com/recipe/classic-caesar-salad","3 romaine hearts, parmeson, croutons, 2 tablespoon olive oil , ranch","lettuce", "https://www.bonappetit.com/recipe/classic-caesar-salad");

                db.addData("Holiday Lettuce Salad","https://www.tasteofhome.com/wp-content/uploads/2017/10/Holiday-Lettuce-Salad_exps41195_CW132792B07_09_6bC_RMS-696x696.jpg","10 cups torn romaine, 2 medium red apples, cubed, 2 medium pears, cubed, 1 cup shredded Swiss cheese, 1/2 cup dried cranberries, 6 tablespoons lemon juice, 3 tablespoons canola oil, 3 tablespoons light corn syrup,1-1/2 teaspoons grated onion, 1-1/2 teaspoons, Dijon mustard, 1/2 teaspoon salt 1/2 cup chopped lightly salted cashews","lettuce", "https://www.tasteofhome.com/recipes/holiday-lettuce-salad");

                //pork chop
                db.addData("Oven-Fried Pork Chops", "https://images.media-allrecipes.com/userphotos/560x315/1908299.jpg", "½ teapsoon garlic powder, 1 pinch pound ginger, 1 cup bread crumbs, 4 pork chops, 1 medium egg, 3 tablespoons of soy sauce", "pork chops", "https://www.allrecipes.com/recipe/239948/easy-oven-fried-pork-chops");

                db.addData("Summer Grilled Pork Chops", "https://images.media-allrecipes.com/userphotos/560x315/4559332.jpg", "1 ½ cups lemon juice, 1 ½ honey, 1 clove garlic minced, ¼ teaspoon dried basil, 4 center-cut pork chops, ½-inch thick, salt and pepper", "pork chops", "https://www.allrecipes.com/recipe/218079/summer-grilled-pork-chops");

                db.addData("Tangy Sliced Pork Sandwiches", "https://images.media-allrecipes.com/userphotos/250x250/188603.jpg", "¼ cup butter, 2 tablespoons of lemon juice, 2 tablespoons white sugar, ¼ teaspoon paprika, ⅛ teaspoon salt, ½ pound boneless pork cooked and cubed, hamburger buns", "pork chops", "https://www.allrecipes.com/recipe/14706/tangy-sliced-pork-sandwiches");

                // salmon
                db.addData("Oven Baked Salmon"," https://food.fnr.sndimg.com/content/dam/images/food/fullset/2011/7/26/1/CN1B01_oven-baked-salmon_s4x3.jpg.rend.hgtvcom.826.620.suffix/1382545141944.jpeg","12 ounce salmon fillet, cut into 4 pieces, Coarse-grained salt, Freshly ground black pepper, Toasted Almond Parsley Salsa, for serving, Baked squash, for serving, optional","salmon", "https://www.foodnetwork.com/recipes/oven-baked-salmon-recipe-1911951");

                db.addData("Garlic Brown Sugar Glazed Salmon", "https://therecipecritic.com/wp-content/uploads/2017/12/brown_sugar_garlic_salmon-1-of-1.jpg", "2 pounds salmon, Atlantic salmon, 2 Tablespoons olive oil, ¼ cup brown sugar, ¼ cup soy sauce, 3 garlic cloves, minced, juice of one lemon,1 teaspoon salt, ½ teaspoon pepper, garnish with sliced lemons and chopped parsley if desired", "salmon", "https://therecipecritic.com/garlic-brown-sugar-glazed-salmon/");

                db.addData("Baked Salmon in Foil", "https://www.wellplated.com/wp-content/uploads/2018/06/Baked-Salmon-in-Foil-at-400-600x847.jpg", "2 pound side of salmon, 5 springs fresh rosemary, 2 small lemons , 2 tablespoons extra virgin olive oil, 1 teaspoon kosher salt , 1/4 teaspoon ground black pepper, 4 cloves garlic — peeled and roughly chopped, additional chopped fresh herbs", "salmon", "https://www.wellplated.com/baked-salmon-in-foil/");

                toastMessage("Added lettuce, pork chop, salmon to Database");
                */

                openView(str1, str2, str3);

            }
        });
    }

    public void openView(String str1, String str2, String str3){
        Intent intent = new Intent(this, view.class);
        intent.putExtra(EXTRA_NUMBER1, str1);
        intent.putExtra(EXTRA_NUMBER2, str2);
        intent.putExtra(EXTRA_NUMBER3, str3);

        startActivity(intent);
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
