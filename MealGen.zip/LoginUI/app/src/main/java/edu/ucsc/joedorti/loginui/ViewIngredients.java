package edu.ucsc.joedorti.loginui;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewIngredients extends AppCompatActivity {
    DatabaseHelperIngredients myDB;
    ArrayList<UserIngredients> userList;
    UserIngredients user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_ingredients);
        ListView listView = (ListView) findViewById(R.id.listview);
        myDB = new DatabaseHelperIngredients(this);
        userList = new ArrayList<>();
        Cursor data = myDB.getData();
        int numRows = data.getCount();

        if (numRows == 0){
            Toast.makeText(this, "The database was empty :c !", Toast.LENGTH_LONG).show();
        }else{
            int i = 0;
            while (data.moveToNext()){
                user = new UserIngredients(data.getString(0), data.getString(1));
                userList.add(i, user);
                //listView.setAdapter(listAdapter);
            }
            TwoColumnListAdaptor adapter =  new TwoColumnListAdaptor(this,R.layout.listadaptorview, userList);
            listView = findViewById(R.id.listview);
            listView.setAdapter(adapter);
        }

}
}
