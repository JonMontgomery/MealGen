package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;

public class view extends AppCompatActivity {

    public static final String SINGLE = "com.example.connormonson.assignment2.SINGLE";
    public static final String LINK = "com.example.connormonson.assignment2.LINK";

    DatabaseHelper myDatabaseHelper;
    ListView lv;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        works();

    }

    public void works(){
        Intent intent = getIntent();
        String str1 = intent.getStringExtra(UserActivity.EXTRA_NUMBER1);
        String str2 = intent.getStringExtra(UserActivity.EXTRA_NUMBER2);
        String str3 = intent.getStringExtra(UserActivity.EXTRA_NUMBER3);

        myDatabaseHelper = new DatabaseHelper(this);
        lv = (ListView) findViewById(R.id.list1);

        Cursor data = myDatabaseHelper.Exists(str1, str2, str3);
        //Cursor data = myDatabaseHelper.getListContents();
        final ArrayList<String> listData = new ArrayList<String>();
        final ArrayList<String> links = new ArrayList<String>();
        if(data.getCount() == 0){
            toastMessage("Error! Ingredients not found");
        }
        int j = 1;
        while(data.moveToNext()){
            //get values from db in first column and add
            listData.add("Meal Option #" + j + "\n" + data.getString(1) + "\n \n" + "Picture: " + data.getString(2) + "\n \n" + "Ingredients: \n" + data.getString(3) +
                    "\n \n" + "Link to Recipe: \n" + data.getString(5));
            links.add(data.getString(5));
            j++;
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent1 = new Intent(view.getContext(), singleView.class);
                intent1.putExtra(SINGLE, listData.get(i));
                intent1.putExtra(LINK, links.get(i));
                startActivity(intent1);
            }
        });
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
