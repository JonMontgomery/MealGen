
package edu.ucsc.joedorti.loginui;

public class UserIngredients {

    private String entry1;
    private String entry2;

    public UserIngredients(String fEntry1,String fEntry2){
        entry1 = fEntry1;
        entry2 = fEntry2;
    }

    public String getEntry1() {
        return entry1;
    }



    public String getEntry2() {
        return entry2;
    }



}
