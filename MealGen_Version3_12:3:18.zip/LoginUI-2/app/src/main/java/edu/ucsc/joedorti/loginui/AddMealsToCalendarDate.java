package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddMealsToCalendarDate extends AppCompatActivity {

    public static final String EXTRA_NUMBER1 = "com.example.connormonson.assignment2.EXTRA_NUMBER1";
    public static final String EXTRA_NUMBER2 = "com.example.connormonson.assignment2.EXTRA_NUMBER2";
    public static final String EXTRA_NUMBER3 = "com.example.connormonson.assignment2.EXTRA_NUMBER3";

    private Button searchButton;
    EditText et1;
    EditText et2;
    EditText et3;
    private TextView tvUser;
    String currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_meals_to_calendar_date);

        Intent intent = getIntent();
        currentDate = intent.getStringExtra("calendarDate");

        et1 = (EditText) findViewById(R.id.edittext1);
        et2 = (EditText) findViewById(R.id.edittext2);
        et3 = (EditText) findViewById(R.id.edittext3);

        searchButton = (Button) findViewById(R.id.buttonDone);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str1 = et1.getText().toString();
                String str2 = et2.getText().toString();
                String str3 = et3.getText().toString();

                openView(str1, str2, str3);

            }
        });
    }

    public void openView(String str1, String str2, String str3){
        Intent intent = new Intent(this, AddMealsToCalendarDateView.class);
        intent.putExtra("num1", str1);
        intent.putExtra("num2", str2);
        intent.putExtra("num3", str3);
        intent.putExtra("calendarDate", currentDate);

        startActivity(intent);
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
