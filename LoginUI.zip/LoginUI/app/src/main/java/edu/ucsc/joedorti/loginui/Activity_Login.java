package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.RelativeLayout;
import android.os.Handler;

import java.util.List;

public class Activity_Login extends AppCompatActivity {

    //initialize variables. buttons. layouts. edittexts
    private EditText usernameInput;
    private EditText passwordInput;

    private Button btnLogin;
    private Button btnSignUp;
    private Button btnForgotPass;

    RelativeLayout rellay1, rellay2;

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            rellay2.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__login);

        btnLogin = findViewById(R.id.btnLogin);
        btnSignUp = findViewById(R.id.btnSignUp);
        btnForgotPass = findViewById(R.id.btnForgotPass);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        final DatabaseHelperLogin dbHelper = new DatabaseHelperLogin(this);

        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        rellay2 = (RelativeLayout) findViewById(R.id.rellay2);

        handler.postDelayed(runnable, 5000); //2000 is the timeout for the splash

        btnForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Activity_Login.this, "Make a new account for now", Toast.LENGTH_SHORT).show();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!emptyValidation()) {
                    dbHelper.addUser(new User(usernameInput.getText().toString(), passwordInput.getText().toString()));
                    Toast.makeText(Activity_Login.this, "Added User", Toast.LENGTH_SHORT).show();
                    usernameInput.setText("");
                    passwordInput.setText("");
                }else{
                    Toast.makeText(Activity_Login.this, "Empty Fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!emptyValidation()) {
                    User user = dbHelper.queryUser(usernameInput.getText().toString(), passwordInput.getText().toString());
                    if (user != null) {
                        Bundle mBundle = new Bundle();
                        mBundle.putString("user", user.getEmail());
                        Intent intent = new Intent(Activity_Login.this, UserActivity.class);
                        intent.putExtras(mBundle);
                        startActivity(intent);
                        Toast.makeText(Activity_Login.this, "Welcome to MealGen " + user.getEmail(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Activity_Login.this, "User not found", Toast.LENGTH_SHORT).show();
                        passwordInput.setText("");
                    }
                }else{
                    Toast.makeText(Activity_Login.this, "Empty Fields", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    private boolean emptyValidation() {
        if (TextUtils.isEmpty(usernameInput.getText().toString()) || TextUtils.isEmpty(passwordInput.getText().toString())) {
            return true;
        }else {
            return false;
        }
    }

}
