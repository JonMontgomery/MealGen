package com.example.connormonson.mealgen_version1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_NUMBER1 = "com.example.connormonson.assignment2.EXTRA_NUMBER1";
    public static final String EXTRA_NUMBER2 = "com.example.connormonson.assignment2.EXTRA_NUMBER2";
    public static final String EXTRA_NUMBER3 = "com.example.connormonson.assignment2.EXTRA_NUMBER3";

    private Button searchButton;
    EditText et1;
    EditText et2;
    EditText et3;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = (EditText) findViewById(R.id.edittext1);
        et2 = (EditText) findViewById(R.id.edittext2);
        et3 = (EditText) findViewById(R.id.edittext3);
        db = new DatabaseHelper(this);

        searchButton = (Button) findViewById(R.id.buttonDone);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str1 = et1.getText().toString();
                String str2 = et2.getText().toString();
                String str3 = et3.getText().toString();

                /*
                db.addData("eggs");
                db.addData("bacon");
                db.addData("sausage");
                db.addData("steak");
                db.addData("chicken");
                */
                /*
                db.addData("Chicken Parmeson","https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg","4 skinless boneless chicken breast halves, 2 eggs , 1/2 cup of tomato sause, 1/2 cup of grated parmeson cheese, 2 tablespoons flour, salt, pepper, 1/4 cup chopped fresh basil, 1 tablespoon olive oil", "chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                db.addData("Crispy Fried Chicken","https://images.media-allrecipes.com/userphotos/720x405/2142598.jpg","1 cup buttermilk , 2 cups flour, 2 cups paprika, salt, pepper,1 cup vegetable oil","chicken","https://www.allrecipes.com/recipe/8805/crispy-fried-chicken/");

                db.addData("Chicken Katsu","https://images.media-allrecipes.com/userphotos/600x600/5816671.jpg","1 egg , 2 tablespoons flour, 1 cup panko bread crumbs, salt, pepper, 1 cup olive oil","chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");

                db.addData("Chicken Sandwich","https://www.tasteofhome.com/wp-content/uploads/2017/10/exps105419_LR153742D08_04_6b--696x696.jpg","1/4 cup reduced-fat mayonnaise, 1 tablespoon Dijon mustard, 1 tablespoon honey, 4 boneless skinless chicken breast halves (4 ounces each),1/2 teaspoon Montreal steak seasoning, 4 slices Swiss cheese, 4 whole wheat hamburger buns split,2 bacon strips cooked and crumbled, Lettuce leaves and tomato slices","chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/");
                */

                //toastMessage("Added Chicken to Database");

                openView(str1, str2, str3);

            }
        });
    }

    public void openView(String str1, String str2, String str3){
        Intent intent = new Intent(this, view.class);
        intent.putExtra(EXTRA_NUMBER1, str1);
        intent.putExtra(EXTRA_NUMBER2, str2);
        intent.putExtra(EXTRA_NUMBER3, str3);

        startActivity(intent);
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
