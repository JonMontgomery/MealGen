package com.example.connormonson.mealgen_version1;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;

public class view extends AppCompatActivity {

    DatabaseHelper myDatabaseHelper;
    ListView lv;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        Intent intent = getIntent();
        String str1 = intent.getStringExtra(MainActivity.EXTRA_NUMBER1);
        String str2 = intent.getStringExtra(MainActivity.EXTRA_NUMBER2);
        String str3 = intent.getStringExtra(MainActivity.EXTRA_NUMBER3);

        myDatabaseHelper = new DatabaseHelper(this);
        lv = (ListView) findViewById(R.id.list1);

        Cursor data = myDatabaseHelper.Exists(str1, str2, str3);
        //Cursor data = myDatabaseHelper.getListContents();
        ArrayList<String> listData = new ArrayList<String>();
        if(data.getCount() == 0){
            toastMessage("Error! Ingredients not found");
        }
        while(data.moveToNext()){
            //get values from db in first column and add
            listData.add("ID =" + data.getString(0) + ". Ingredient: "  + data.getString(1));
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        lv.setAdapter(adapter);
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
