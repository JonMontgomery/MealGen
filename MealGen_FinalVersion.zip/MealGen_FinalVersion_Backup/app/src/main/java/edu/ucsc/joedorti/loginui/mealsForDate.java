package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class mealsForDate extends AppCompatActivity {

    ListView lv;
    ArrayAdapter<String> adapter;
    TextView tv;
    DatabaseMealsForDate myDatabaseHelper;
    String currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meals_for_date);

        tv = (TextView) findViewById(R.id.dateDisplay);
        Intent intent = getIntent();
        currentDate = intent.getStringExtra("calendarDate");
        tv.setText(currentDate);

        myDatabaseHelper = new DatabaseMealsForDate(this);
        //myDatabaseHelper.addData("Chicken Parmeson","https://images.media-allrecipes.com/userphotos/720x405/4572704.jpg","4 skinless boneless chicken breast halves, 2 eggs , 1/2 cup of tomato sause, 1/2 cup of grated parmeson cheese, 2 tablespoons flour, salt, pepper, 1/4 cup chopped fresh basil, 1 tablespoon olive oil", "chicken","https://www.allrecipes.com/recipe/223042/chicken-parmesan/", "1242018");
        lv = (ListView) findViewById(R.id.items_list);

        Cursor data = myDatabaseHelper.Exists(currentDate);
        //Cursor data = myDatabaseHelper.getListContents();
        final ArrayList<String> listData = new ArrayList<String>();
        final ArrayList<String> links = new ArrayList<String>();
        if(data.getCount() == 0){
            toastMessage("No Meals Currently set for Selected Date");
        }
        int j = 1;
        while(data.moveToNext()){
            //get values from db in first column and add
            listData.add("Meal Option #" + j + "\n" + data.getString(1) + "\n \n" + "Picture: " + data.getString(2) + "\n \n" + "Ingredients: \n" + data.getString(3) +
                    "\n \n" + "Link to Recipe: \n" + data.getString(5));
            links.add(data.getString(5));
            j++;
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        lv.setAdapter(adapter);

    }
    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

}
