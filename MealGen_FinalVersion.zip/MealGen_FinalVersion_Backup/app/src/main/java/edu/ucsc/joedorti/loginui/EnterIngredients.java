package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class EnterIngredients extends AppCompatActivity {
    TextView ingredient;
    Button btnDelete;
    Button btnSearch;
    DatabaseHelper myDatabaseHelper;
    String str1;
    int pos;
    private ArrayList<String> allitems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_ingredients);

        final Intent intent = getIntent();
        str1 = intent.getStringExtra("ingredient");
        pos = intent.getIntExtra("test", pos);
        allitems = intent.getStringArrayListExtra("arrayItems");
        ingredient = (TextView) findViewById(R.id.name1);
        ingredient.setText(str1);

        myDatabaseHelper = new DatabaseHelper(this);
        btnDelete = (Button) findViewById(R.id.buttonDelete);
        btnSearch = (Button) findViewById(R.id.buttonSearch);

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allitems.remove(pos);
                finish();
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EnterIngredients.this, view.class);
                intent.putExtra("num1", str1);
                intent.putExtra("num2", "");
                intent.putExtra("num3", "");

                //intent.putExtra(EXTRA_NUMBER1, str1);
                //intent.putExtra(EXTRA_NUMBER2, str2);
                //intent.putExtra(EXTRA_NUMBER3, str3);

                startActivity(intent);
            }
        });

    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}