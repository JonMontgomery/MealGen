package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserActivity extends MainActivity {
    private TextView tvUser;

    public static final String EXTRA_NUMBER1 = "com.example.connormonson.assignment2.EXTRA_NUMBER1";
    public static final String EXTRA_NUMBER2 = "com.example.connormonson.assignment2.EXTRA_NUMBER2";
    public static final String EXTRA_NUMBER3 = "com.example.connormonson.assignment2.EXTRA_NUMBER3";

    private Button searchButton;
    EditText et1;
    EditText et2;
    EditText et3;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        tvUser = findViewById(R.id.tvUser);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            tvUser.setText(bundle.getString("user"));
        }

        et1 = (EditText) findViewById(R.id.edittext1);
        et2 = (EditText) findViewById(R.id.edittext2);
        et3 = (EditText) findViewById(R.id.edittext3);
        db = new DatabaseHelper(this);

        searchButton = (Button) findViewById(R.id.buttonDone);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str1 = et1.getText().toString();
                String str2 = et2.getText().toString();
                String str3 = et3.getText().toString();

                openView(str1, str2, str3);

            }
        });
    }
    /*
     * put all the activities here
     * */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.get_meal) {
            // Handle the meal action
            Intent intent = new Intent(UserActivity.this, UserActivity.class);
            startActivity(intent);

        } else if (id == R.id.view_meals) {
            Intent intent = new Intent(UserActivity.this, ViewAll.class);
            startActivity(intent);

        } else if (id == R.id.ingredients) {
            Intent intent = new Intent(UserActivity.this, IngredientList.class);
            startActivity(intent);
        } else if (id == R.id.calander) {
            Intent intent = new Intent(UserActivity.this, CalendarActivity.class);
            startActivity(intent);
        } else if (id == R.id.favorites) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }else if (id == R.id.Logout) { finish();
            Intent intent = new Intent(getApplicationContext(), Activity_Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);

        }else if (id == R.id.Exit) { Intent homeIntent = new Intent(Intent.ACTION_MAIN);
            Intent intent = new Intent(getApplicationContext(), Activity_Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            homeIntent.addCategory( Intent.CATEGORY_HOME );
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(homeIntent);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void openView(String str1, String str2, String str3){
        Intent intent = new Intent(this, view.class);
        intent.putExtra("num1", str1);
        intent.putExtra("num2", str2);
        intent.putExtra("num3", str3);

        //intent.putExtra(EXTRA_NUMBER1, str1);
        //intent.putExtra(EXTRA_NUMBER2, str2);
        //intent.putExtra(EXTRA_NUMBER3, str3);

        startActivity(intent);
    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}