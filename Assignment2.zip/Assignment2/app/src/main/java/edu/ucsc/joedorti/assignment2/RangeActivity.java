package edu.ucsc.joedorti.assignment2;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Range;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

public class RangeActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    EditText editTextRangeA, editTextRangeB;
    Button btnDisplayRange;

    //initialize strings to pass into view
    public static final String EXTRA_NUM1 = "pau";
    public static final String EXTRA_NUM2 = "cu";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_range);

        editTextRangeA = findViewById(R.id.editTextRangeA);
        editTextRangeB = findViewById(R.id.editTextRangeB);

        btnDisplayRange = findViewById(R.id.btnDisplayRange);

        myDB = new DatabaseHelper(this);



        btnDisplayRange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(editTextRangeA.length() == 0 || editTextRangeB.length() == 0){
                    Toast.makeText(RangeActivity.this, "You must put numbers in both of the text fields !", Toast.LENGTH_LONG).show();
                }else {

                    int v1 = Integer.parseInt(editTextRangeA.getText().toString());
                    int v2 = Integer.parseInt(editTextRangeB.getText().toString());

                    if (v1 < v2) {

                        Intent intent5 = new Intent(RangeActivity.this, RangeViewActivity.class);
                        //added
                        intent5.putExtra(EXTRA_NUM1, v1);
                        intent5.putExtra(EXTRA_NUM2, v2);
                        startActivity(intent5);

                    }else {
                        Toast.makeText(RangeActivity.this, "The first number must be smaller than the second one !", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

    }
}
