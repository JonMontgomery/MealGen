package edu.ucsc.joedorti.assignment2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    EditText editTextID, editTextImageTitle;
    Button btnDeleteImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        editTextID = findViewById(R.id.editTextID);
        editTextImageTitle = findViewById(R.id.editTextImageTitle);

        btnDeleteImage = findViewById(R.id.btnDeleteImage);

        myDB = new DatabaseHelper(this);

        //deleteData();

        //onclick listener for delete button
        //modified
        //public void deleteData(){
        btnDeleteImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (editTextID.getText().toString().trim().length() > 0) {
                        Integer deletedRows = myDB.deleteData(editTextID.getText().toString());
                        if (deletedRows > 0)
                            Toast.makeText(DeleteActivity.this, "Data Deleted !", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(DeleteActivity.this, "Data not Deleted !", Toast.LENGTH_LONG).show();

                    }

                    if (editTextImageTitle.getText().toString().trim().length() > 0){
                        Integer deletedRows2 = myDB.deleteData2(editTextImageTitle.getText().toString());
                        if (deletedRows2 > 0)
                            Toast.makeText(DeleteActivity.this, "Data Deleted !", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(DeleteActivity.this, "Data not Deleted !", Toast.LENGTH_LONG).show();
                    }

                }
            });
        //}

    }

}

