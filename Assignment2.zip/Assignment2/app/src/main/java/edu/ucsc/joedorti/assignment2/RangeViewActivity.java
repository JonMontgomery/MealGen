package edu.ucsc.joedorti.assignment2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class RangeViewActivity extends AppCompatActivity{

    DatabaseHelper myDB;
    ArrayList<User> userList, userList2;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_range_view);

        //import values
        Intent intent = getIntent();
        int num1 = intent.getIntExtra(RangeActivity.EXTRA_NUM1, 0);
        int num2 = intent.getIntExtra(RangeActivity.EXTRA_NUM2, 0);

        ListView listView2 = (ListView) findViewById(R.id.listView2);
        myDB = new DatabaseHelper(this);

        userList = new ArrayList<>();
        Cursor data = myDB.getListContents();

        int numRows = data.getCount();

        if (numRows == 0){
            Toast.makeText(this, "The database was empty :c !", Toast.LENGTH_LONG).show();
        }else{
            //int i = 0;
            while (data.moveToNext()){
                user = new User(data.getString(0), data.getString(1), data.getString(2));
                userList.add(user);
                //listView.setAdapter(listAdapter);
            }

            userList2 = new ArrayList<>();

            for (int j = num1-1; j <= num2-1; j++){
                userList2.add(userList.get(j));
            }



            ThreeColumn_ListAdapter adapter =  new ThreeColumn_ListAdapter(this,R.layout.list_adapter_view, userList2);
            listView2 = findViewById(R.id.listView2);
            listView2.setAdapter(adapter);
        }

    }

}
