package edu.ucsc.joedorti.assignment2;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize our buttons
        Button btnDownload = (Button) findViewById(R.id.btnDownload);
        Button btnDelete = (Button) findViewById(R.id.btnDelete);
        Button btnView = (Button) findViewById(R.id.btnView);
        Button btnRange = (Button) findViewById(R.id.btnRange);

        //add click listeners

        //download button
        btnDownload.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

               /* //add intent
                Intent startIntent = new Intent(getApplicationContext(), EnterInfo.class);
                //show how to pass information to another activity
                startIntent.putExtra("joedorti.ucsc.edu.assignment1.SOMETHING", "Hello World !");
                startActivity(startIntent); */

                Intent intent1 = new Intent(MainActivity.this, DownloadActivity.class);
                startActivity(intent1);

            }
        });

        //delete button
        btnDelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

               /* //add intent
                Intent startIntent = new Intent(getApplicationContext(), EnterInfo.class);
                //show how to pass information to another activity
                startIntent.putExtra("joedorti.ucsc.edu.assignment1.SOMETHING", "Hello World !");
                startActivity(startIntent); */

                Intent intent2 = new Intent(MainActivity.this, DeleteActivity.class);
                startActivity(intent2);

            }
        });

        //view button
        btnView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

               /* //add intent
                Intent startIntent = new Intent(getApplicationContext(), EnterInfo.class);
                //show how to pass information to another activity
                startIntent.putExtra("joedorti.ucsc.edu.assignment1.SOMETHING", "Hello World !");
                startActivity(startIntent); */

                Intent intent3 = new Intent(MainActivity.this, ViewActivity.class);
                startActivity(intent3);

            }
        });

        //range button
        btnRange.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

               /* //add intent
                Intent startIntent = new Intent(getApplicationContext(), EnterInfo.class);
                //show how to pass information to another activity
                startIntent.putExtra("joedorti.ucsc.edu.assignment1.SOMETHING", "Hello World !");
                startActivity(startIntent); */

                Intent intent4 = new Intent(MainActivity.this, RangeActivity.class);
                startActivity(intent4);

            }
        });

    }
}
