package edu.ucsc.joedorti.assignment2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

public class DownloadActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    EditText editTextURL, editTextTitle;
    Button btnDownloadImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);

        editTextURL = findViewById(R.id.editTextURL);
        editTextTitle = findViewById(R.id.editTextTitle);

        btnDownloadImage = findViewById(R.id.btnDownloadImage);

        myDB = new DatabaseHelper(this);


        //onclick listener for download button
        //modified
        btnDownloadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry1 = editTextURL.getText().toString();
                String newEntry2 = editTextTitle.getText().toString();

                if (newEntry1.length() != 0 && newEntry2.length() != 0 ){
                    AddData(newEntry1, newEntry2);
                    editTextURL.setText("");
                    editTextTitle.setText("");
                }else{
                    Toast.makeText(DownloadActivity.this, "You must put something in the text field !", Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    public void AddData(String newEntry1, String newEntry2){
        boolean insertData = myDB.addData(newEntry1, newEntry2);

        if (insertData == true){
            Toast.makeText(DownloadActivity.this, "Successfully entered data !", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(DownloadActivity.this, "Something went wrong :c !", Toast.LENGTH_LONG).show();
        }
    }
}
