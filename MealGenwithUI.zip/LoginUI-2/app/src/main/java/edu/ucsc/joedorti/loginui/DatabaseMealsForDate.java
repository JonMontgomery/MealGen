package edu.ucsc.joedorti.loginui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseMealsForDate extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MealsForDate.db";
    public static final String TABLE_NAME = "meals_for_date";
    public static final String COL1 = "ID";
    public static final String COL2 = "ITEM1";
    public static final String COL3 = "ITEM2";
    public static final String COL4 = "ITEM3";
    public static final String COL5 = "ITEM4";
    public static final String COL6 = "ITEM5";
    public static final String COL7 = "ITEM6";


    public DatabaseMealsForDate(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + " ITEM1 TEXT, " + " ITEM2 TEXT, " + " ITEM3 TEXT, " + " ITEM4 TEXT, " + " ITEM5 TEXT, " + " ITEM6 TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME); // may be an issue!!!
        onCreate(db);
    }

    public boolean addData(String item1, String item2, String item3, String item4, String item5, String item6) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item1);
        contentValues.put(COL3, item2);
        contentValues.put(COL4, item3);
        contentValues.put(COL5, item4);
        contentValues.put(COL6, item5);
        contentValues.put(COL7, item6);

        long result = db.insert(TABLE_NAME, null, contentValues);

        //if date inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    //returning all data from database
    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return data;
    }

    public Cursor Exists(String i1){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE "
                + COL7 + " = '" + i1 + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

}
