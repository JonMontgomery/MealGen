package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class IngredientList extends MainActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private EditText itemET;
    private Button btn;
    private ListView itemsList;
    int POS;
    int test = 0;

    private ArrayList<String> items;
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        works();

    }

    private void works() {

        itemET = (EditText) findViewById(R.id.item_edit_text);
        btn = (Button) findViewById(R.id.add_btn);
        itemsList = (ListView) findViewById(R.id.items_list);



        items = FileHelper.readData(this);

        Intent intent = getIntent();
        test = intent.getIntExtra("test", test);

        if( test != 0){
            items.remove(POS);
            adapter.notifyDataSetChanged();
            FileHelper.writeData(items, this);
            Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
            test = 0;
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
        itemsList.setAdapter(adapter);

        btn.setOnClickListener(this);
        itemsList.setOnItemClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.add_btn:
                String itemEntered = itemET.getText().toString();
                adapter.add(itemEntered);
                itemET.setText("");
                FileHelper.writeData(items, this);
                Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
                break;
        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        String str = items.get(position);
        POS = position;

        Intent intent1 = new Intent(view.getContext(), EnterIngredients.class);
        intent1.putExtra("ingredient", str);
        intent1.putExtra("pos", POS);
        intent1.putExtra("arrayItems", items);
        //intent1.putExtra("arrayAdapter", adapter);
        startActivity(intent1);
        FileHelper.writeData(items, this);
        /*
        items.remove(position);
        adapter.notifyDataSetChanged();
        FileHelper.writeData(items, this);
        Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
        */
    }/*
     * put all the activities here
     * */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.get_meal) {
            // Handle the meal action
            Intent intent = new Intent(IngredientList.this, UserActivity.class);
            startActivity(intent);

        } else if (id == R.id.view_meals) {
            Intent intent = new Intent(IngredientList.this, ViewAll.class);
            startActivity(intent);

        } else if (id == R.id.ingredients) {
            Intent intent = new Intent(IngredientList.this, IngredientList.class);
            startActivity(intent);
        } else if (id == R.id.calander) {
            Intent intent = new Intent(IngredientList.this, CalendarActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }else if (id == R.id.Logout) {
            finish();
            System.exit(0);
        }else if (id == R.id.Exit) {
            finish();
            System.exit(0);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
