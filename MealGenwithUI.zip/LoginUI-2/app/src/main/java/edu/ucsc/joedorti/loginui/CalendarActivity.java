package edu.ucsc.joedorti.loginui;


import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;
import android.widget.CalendarView;

public class CalendarActivity extends MainActivity {

    private static final String TAG = "CalendarActivity";
    public static final String DATE = "com.example.connormonson.assignment2.DATE";

    private CalendarView mCalendarView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mCalendarView = (CalendarView) findViewById(R.id.calendarView);

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView calendarView, int i, int i1, int i2) {
                String date = (i1+1) + "/" + i2 + "/" + i;
                Intent intent1 = new Intent(calendarView.getContext(), singleViewCalendar.class);
                intent1.putExtra("calendarDate", date);
                //intent1.putExtra("LINK", date);
                startActivity(intent1);
                Log.d(TAG, "onSelectedDayChange: date: " + date);
            }
        });
    }/*
     * put all the activities here
     * */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.get_meal) {
            // Handle the meal action
            Intent intent = new Intent(CalendarActivity.this, UserActivity.class);
            startActivity(intent);

        } else if (id == R.id.view_meals) {
            Intent intent = new Intent(CalendarActivity.this, ViewAll.class);
            startActivity(intent);

        } else if (id == R.id.ingredients) {
            Intent intent = new Intent(CalendarActivity.this, IngredientList.class);
            startActivity(intent);
        } else if (id == R.id.calander) {
            Intent intent = new Intent(CalendarActivity.this, CalendarActivity.class);
            startActivity(intent);
        } else if (id == R.id.favorites) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }else if (id == R.id.Logout) {

        }else if (id == R.id.Exit) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
