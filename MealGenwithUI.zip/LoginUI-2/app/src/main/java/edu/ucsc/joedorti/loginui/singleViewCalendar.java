package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class singleViewCalendar extends AppCompatActivity {

    public static final String SINGLE = "com.example.connormonson.assignment2.SINGLE";
    public static final String LINK = "com.example.connormonson.assignment2.LINK";

    DatabaseHelper myDatabaseHelper;
    ListView lv;
    ArrayAdapter<String> adapter;
    TextView tv;
    String date;
    Button current;
    Button search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_view_calendar);

        tv = (TextView) findViewById(R.id.display);
        Intent intent = getIntent();
        date = intent.getStringExtra("calendarDate");
        tv.setText(date);

        current = (Button) findViewById(R.id.mealsForDate);
        search = (Button) findViewById(R.id.searchMeals);

        current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(singleViewCalendar.this, mealsForDate.class);
                intent.putExtra("calendarDate", date);
                startActivity(intent);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(singleViewCalendar.this, AddMealsToCalendarDate.class);
                intent.putExtra("calendarDate", date);
                startActivity(intent);
            }
        });

        //works();

        //String str2 = intent.getStringExtra();
    }

    public void works(){
        myDatabaseHelper = new DatabaseHelper(this);
        lv = (ListView) findViewById(R.id.items_list);

        Cursor data = myDatabaseHelper.getListContents();
        final ArrayList<String> listData = new ArrayList<String>();
        final ArrayList<String> links = new ArrayList<String>();
        if(data.getCount() == 0){
            toastMessage("Error! Ingredients not found");
        }
        int j = 1;
        while(data.moveToNext()){
            //get values from db in first column and add
            listData.add("Meal Option #" + j + "\n" + data.getString(1) + "\n \n" + "Picture: " + data.getString(2) + "\n \n" + "Ingredients: \n" + data.getString(3) +
                    "\n \n" + "Link to Recipe: \n" + data.getString(5));
            links.add(data.getString(5));
            j++;
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent1 = new Intent(view.getContext(), singleView.class);
                intent1.putExtra(SINGLE, listData.get(i));
                intent1.putExtra(LINK, links.get(i));
                startActivity(intent1);
            }
        });
    }
    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
