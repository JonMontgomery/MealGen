package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EnterIngredientsCorrect extends AppCompatActivity {

    Button addButton;
    Button viewButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_ingredients_correct);

        addButton = (Button) findViewById(R.id.addbutton);
        viewButton = (Button) findViewById(R.id.viewbutton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EnterIngredientsCorrect.this, EnterIngredients.class);
                startActivity(intent);
            }
        });

        viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EnterIngredientsCorrect.this, ViewIngredients.class);
                startActivity(intent);
            }
        });
    }
}
