package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewIngredients extends AppCompatActivity {
    DatabaseHelperIngredientsList myDB;
    ListView lv;
    ArrayAdapter<String> adapter;

    //ArrayList<UserIngredients> userList;
    UserIngredients user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_ingredients);

        works();

        //notWorking();

    }

    public void works(){
        lv = (ListView) findViewById(R.id.listview);
        myDB = new DatabaseHelperIngredientsList(this);
        //Cursor data2 = myDB.getItemID()
        Cursor data1 = myDB.getListContents();
        final ArrayList<String> listData = new ArrayList<String>();
        if(data1.getCount() == 0){
            toastMessage("Error! Ingredients not found");
        } else{
            while(data1.moveToNext()){
                //get values from db in first column and add
                listData.add("Ingredient: " + data1.getString(1));
                //Cursor data2 = myDB.getItemID(data1.getString(1));
                //listData.add("Count= " + data2.getString(0) + "Ingredient: " + data1.getString(1));
            }
        }
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });

    }

    private void toastMessage(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
