package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class IngredientList extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private EditText itemET;
    private Button btn;
    private ListView itemsList;
    int POS;
    int test = 0;

    private ArrayList<String> items;
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient_list);

        works();

    }

    private void works() {

        itemET = (EditText) findViewById(R.id.item_edit_text);
        btn = (Button) findViewById(R.id.add_btn);
        itemsList = (ListView) findViewById(R.id.items_list);



        items = FileHelper.readData(this);

        Intent intent = getIntent();
        test = intent.getIntExtra("test", test);

        if( test != 0){
            items.remove(POS);
            adapter.notifyDataSetChanged();
            FileHelper.writeData(items, this);
            Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
            test = 0;
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
        itemsList.setAdapter(adapter);

        btn.setOnClickListener(this);
        itemsList.setOnItemClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.add_btn:
                String itemEntered = itemET.getText().toString();
                adapter.add(itemEntered);
                itemET.setText("");
                FileHelper.writeData(items, this);
                Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
                break;
        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        String str = items.get(position);
        POS = position;

        Intent intent1 = new Intent(view.getContext(), EnterIngredients.class);
        intent1.putExtra("ingredient", str);
        intent1.putExtra("pos", POS);
        intent1.putExtra("arrayItems", items);
        //intent1.putExtra("arrayAdapter", adapter);
        startActivity(intent1);
        FileHelper.writeData(items, this);
        /*
        items.remove(position);
        adapter.notifyDataSetChanged();
        FileHelper.writeData(items, this);
        Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
        */
    }
}
