package edu.ucsc.joedorti.loginui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EnterSingleIngredient extends AppCompatActivity {

    EditText ingredient;
    Button btnAdd;
    DatabaseHelperIngredientsList mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_single_ingredient);

        ingredient = (EditText) findViewById(R.id.edittext1);
        mDatabaseHelper = new DatabaseHelperIngredientsList(this);
        //btnAdd = findViewById(R.id.buttonadd);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ingredient.length() != 0) {
                    mDatabaseHelper.addData(ingredient.getText().toString());
                    ingredient.setText("");
                    finish();
                } else {
                    toastMessage("You must put something in the text field!");
                }

            }
        });
    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}
